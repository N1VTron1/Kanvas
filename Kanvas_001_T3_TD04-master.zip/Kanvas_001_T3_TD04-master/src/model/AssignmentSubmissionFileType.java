package model;

public enum AssignmentSubmissionFileType {
    TXT,
    ZIP,
    DOCX,
    MP4
}
