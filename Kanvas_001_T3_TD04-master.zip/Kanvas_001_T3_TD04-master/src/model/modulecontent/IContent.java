package model.modulecontent;

public interface IContent {
    String getShortDescription();
    String getContentType();
}