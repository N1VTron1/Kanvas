package model.modulecontent;

public abstract class Content {
    boolean isPublished;
}
