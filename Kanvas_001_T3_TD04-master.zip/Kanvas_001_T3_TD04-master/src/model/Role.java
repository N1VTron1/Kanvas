package model;

public enum Role {
    STUDENT,
    TEACHER
}
